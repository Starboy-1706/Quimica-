#!/usr/bin/env bash
# Envoltura fina: TODA la lógica vive en start.sh (raíz del repo), así funciona
# incluso si esta carpeta desaparece. Uso equivalente:
#   bash .devcontainer/codespace.sh dev   ≡   bash start.sh dev
exec bash "$(cd "$(dirname "$0")/.." && pwd)/start.sh" "$@"
